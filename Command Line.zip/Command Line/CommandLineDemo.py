"""
Program to demonstrate Command Line argruments Demo
"""

import sys

print "Command Line argruments : ", len(sys.argv), sys.argv
print "Type of argv : ", type(sys.argv)